import React from 'react'

export default function Register_ThankYou() {
  return (
    <div>
        <img src=''></img>
    </div>
  )
}
