import React from 'react'

export default function Register_NewUser() {
  return (<div>
        <form>
            <div class="form-floating mb-3">
                <label for="floatingFirstName"></label>
                <input style={{marginTop:'15px'}} type="text" class="form-control" id="floatingFirstName" placeholder="שם פרטי"/>
            </div>
            <div class="form-floating mb-3">
                <label for="floatingLastName"></label>
                <input style={{marginTop:'15px'}} type="text" class="form-control" id="floatingLastName" placeholder="שם משפחה"/>
            </div>
            <div class="form-floating mb-3">
                <label for="floatingDOB">תאריך לידה: </label>
                <input style={{marginLeft:'15px', marginTop:'15px'}} type="date" class="form-control" id="floatingDOB"/>
            </div>
            <div class="form-floating mb-3">
                <label for="floatingEmail"></label>
                <input style={{marginTop:'15px'}} type="email" class="form-control" id="floatingEmail" placeholder="אימייל"/>
            </div>
            <div class="form-floating">
                <label for="floatingPassword"></label>
                <input style={{marginTop:'15px'}} type="password" class="form-control" id="floatingPassword" placeholder="בחר סיסמא"/>
            </div>
            <div class="form-floating">
                <label for="floatingPasswordVerify"></label>
                <input style={{marginTop:'15px'}} type="password" class="form-control" id="floatingPasswordVerify" placeholder="הזן סיסמא בשנית"/>
            </div>
            <div class="form-floating mb-3">
                <label for="floatingPhone"></label>
                <input style={{marginTop:'15px'}} type="text" class="form-control" id="floatingPhone" placeholder="טלפון"/>
                
                <select class="form-select" id="floatingPrefix" aria-label="Floating label select example">
                    <option selected>קידומת</option>
                    <option value="1">051</option>
                    <option value="2">052</option>
                    <option value="3">053</option>
                    <option value="4">054</option>
                    <option value="5">055</option>
                    <option value="6">057</option>
                    <option value="7">058</option>
                    <option value="8">02</option>
                    <option value="9">03</option>
                    <option value="10">04</option>
                    <option value="11">08</option>
                </select>
            </div>
            <div class="form-floating" style={{marginTop:'15px'}}>
                <select class="form-select" id="floatingGender" aria-label="Floating label select example">
                    <option selected>מין</option>
                    <option value="1">זכר</option>
                    <option value="2">נקבה</option>
                    <option value="3">לא רוצה לציין</option>
                </select>
                <label for="floatingGender"></label>
            </div>
            <div class="form-floating" style={{marginTop:'15px'}}>
                <select class="form-select" id="floatingStudentType" aria-label="Floating label select example">
                    <option selected>מוסד אקדמי</option>
                    <option value="1">המרכז האקדמי</option>
                    <option value="2">ביה"ס להנדסאים</option>
                </select>
                <label for="floatingStudentType"></label>
            </div>
            <div class="form-floating" id="academyTrue" style={{visibility:''}}>
                <div class="form-floating">
                    <select class="form-select" id="floatingAcademyYear" aria-label="Floating label select example">
                        <option selected>שנת לימודים</option>
                        <option value="1">א'</option>
                        <option value="2">ב'</option>
                        <option value="3">ג'</option>
                        <option value="4">ד'</option>
                    </select>
                    <label for="floatingAcademyYear"></label>
                    <br/>
                    <select class="form-select" id="floatingAcademyFaculty" aria-label="Floating label select example">
                        <option selected>פקולטה</option>
                        <option value="1">הנדסה</option>
                        <option value="2">כלכלה ומנע"ס</option>
                        <option value="3">מדעי הרוח</option>
                        <option value="4">מדעי החברה</option>
                    </select>
                    <label for="floatingAcademyFaculty"></label>
                    <br/>
                    <select class="form-select" id="floatingAcademyClass" aria-label="Floating label select example">
                        <option selected>שנת לימודים</option>
                        <option value="1">א'</option>
                        <option value="2">ב'</option>
                        <option value="3">ג'</option>
                        <option value="4">ד'</option>
                    </select>
                    <label for="floatingAcademyClass"></label>
                </div>
            </div>
            <div class="form-floating" id="engineerTrue" style={{visibility:'hidden'}}>
                <div class="form-floating">
                    <select class="form-select" id="floatingEngineerYear" aria-label="Floating label select example">
                        <option selected>שנת לימודים</option>
                        <option value="1">א'</option>
                        <option value="2">ב'</option>
                        <option value="3">ג'</option>
                    </select>
                    <label for="floatingEngineerYear"></label>
                    <select class="form-select" id="floatingEngineerMegama" aria-label="Floating label select example">
                        <option selected>מגמה</option>
                        <option value="1">תוכנה</option>
                        <option value="2">רכב</option>
                        <option value="3">אדריכלות</option>
                        <option value="4">נוף</option>
                        <option value="5">בניין</option>
                    </select>
                    <label for="floatingEngineerMegama"></label>
                </div>
            </div>
        </form>
    </div>
  )
}
