import React from 'react';
import { Component } from 'react';
import Login from './Login/Login';
import Profile from './Profile/Profile';
import { TableHead } from './Profile/Profile';
import Register_NewUser from '../Screens/Register/Register_NewUser';
import { useState } from 'react';
import { render } from '@testing-library/react';

export default function Main(props) {

  const [courseCode, SetCourseCode] = useState(2);
  const [courseName, setCourseName] = useState("הכנה לפרויקט גמר")
  const [CourseDay, setCourseDay] = useState("א'");
  const [CourseHour, setCourseHour] = useState("08:00 - 10:00");
  const [Lecturer, setLecturer] = useState("אניטה אולמן")
  const [LecturerTitle, setLecturerTitle] = useState("M.A");
  const [courseLocation, setCourseLocation] = useState("נובל 6")

  return <div>
      {/* <Register_NewUser/> */}


      <Login/>


      {/* <TableHead/>
      <Profile code={courseCode} name={courseName} day={CourseDay} hour={CourseHour} lecturer={Lecturer} title={LecturerTitle} location={courseLocation}/>
      <Profile code={1} name={"תכנות מונחה עצמים"} day={"ב'"} hour={"10:15 - 12:45"} lecturer={"שי אברהם"} title={"M.A"} location={"רימון 2"}/> */}


    </div>;
  }

