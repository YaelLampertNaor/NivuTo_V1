import { keyboard } from '@testing-library/user-event/dist/keyboard';
import React from 'react'

export default function Login() {
    
  return (
    <div style={{display:'flex', flexDirection:'column'}}>
        <div class="form-floating mb-3">
            <input type="email" id="loginEmail" class="form-control"placeholder="אימייל"/>
            <label for="loginEmail"></label>
        </div>
        <div class="form-floating" style={{marginTop:'15px'}}>
            <input type="password" id="loginPassword" class="form-control" onChange={OnChangePassword} placeholder="סיסמא"/>
            <label for="loginPassword"></label>
        </div>
        <button style={{blockSize:'30px', width:'50px', marginRight:'60px', marginTop:'20px'}} class="btn btn-primary" onClick={LoginBtnClick}>כניסה</button>
    </div>
  )
}

function LoginBtnClick(){
    alert("כפתור 'כניסה' נלחץ");
};

function OnChangePassword(){
    let password = document.querySelector(`#loginPassword`);
    password.addEventListener('keydown', (event)=>{
        password+=event.key;
		console.log(`Key: ${event.key} with keycode ${event.keyCode} has been pressed`);
        console.log(password);
        }
    )
}