import React from 'react'
import { Table } from 'react-bootstrap'

export default function Profile(props) {
    
  return (
    <div>
        <Table>
            <tbody>
                <tr>
                    <td className='courseCode'>{props.code}</td>
                    <td className='courseName' style={{paddingRight:'90px'}}>{props.name}</td>
                    <td style={{paddingRight:'70px'}}><span className='day'>{props.day}</span><span className='hour' style={{paddingRight:'10px'}}>{props.hour}</span></td>
                    <td className='lecturer' style={{paddingRight:'50px'}}>{props.lecturer}<span className='title'> M.A</span></td>
                    <td className='courseLocation' style={{paddingRight:'50px'}}><a href='/'>{props.location}</a></td>
                </tr>
            </tbody>
        </Table>   
    </div>
  )
};

export function TableHead(){
    return(
        <div>
            <img src="http://www.mcicon.com/wp-content/uploads/2020/12/Education_Student_1-copy.jpg" style={{blockSize:'190px', borderRadius:'100px', border:'1px solid black', display:'flex', flexDirection:'row', justifyContent:'center'}} class="img-thumbnail" alt="Add profile picture"></img>
            <p className='h1'>שלום שם,</p>
            <br/>
            <br/>
            <p className='h1'>מערכת השעות שלך:</p>
            <Table>
                <thead>
                    <tr>
                        <th>קוד שיעור</th>
                        <th style={{paddingRight:'30px'}}>שיעור</th>
                        <th style={{paddingRight:'155px'}}>יום ושעה</th>
                        <th style={{paddingRight:'100px'}}>מרצה</th>
                        <th style={{paddingRight:'125px'}}>מיקום</th>
                    </tr>
                </thead>
            </Table>
        </div>);
};
