import './App.css';
import {BrowserRouter} from 'react-router-dom';
import Main_Layout from './Layout/Main_Layout';


function App() {
  return (
    <BrowserRouter>

      <Main_Layout/>

    </BrowserRouter>
  );
}

export default App;
