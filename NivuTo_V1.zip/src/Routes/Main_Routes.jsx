import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Main from '../Screens/Main';

export default function Main_Routes() {
  return <Routes>

        <Route path="/" element={<Main/>}/>

    </Routes>;
}
