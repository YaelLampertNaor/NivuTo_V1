import React from 'react'

export default function Footer() {
  return (
    <div style={{display:'flex', flexDirection:'row'}}>
        <p>Contact Us</p>
        
    </div>
  )
}
