import React from 'react';
import { Link } from 'react-router-dom';

export default function Header() {
  return<div style={{display:'flex', flexDirection:'column', justifyContent:'center', padding:'5px,5px'}}>

    <span class="material-icons">
    
    </span>
    <div style={{color:"pink", margin:'10px'}}>
      <img src="https://navigation-m.com/images/logotallfoot.png" alt="" srcset="" />
    </div>

  </div>;}
